from quanta import stokes_formalism
print(stokes_formalism.diagonal_negative())
